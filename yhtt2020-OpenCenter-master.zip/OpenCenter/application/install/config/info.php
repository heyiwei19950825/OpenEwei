<?php

use think\facade\Env;

return [
    'install'=>[
        'version'=>'3.0.0开发者预览版',
        'app'=>'OCenter V3'
    ]

];
